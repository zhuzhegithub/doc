package com.work.prober.controller;

import com.work.prober.bean.ProberBO;
import com.work.prober.bean.ResultMap;
import com.work.prober.exception.IllegalCharacterException;
import com.work.prober.exception.OutOfCoordinateException;
import com.work.prober.util.DirectionRuleUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhuzhe
 * @date 2018/8/3 14:29
 * @email zhe.zhu1@outlook.com
 */
@Slf4j
@RequestMapping("/prober")
@RestController
public class ExecuteCommandController {

    @PostMapping("/execute")
    public ResultMap<String> execute(@RequestParam String command) {
        ResultMap<String> resultMap = new ResultMap<>();
        String resultT = "";
        try {
            String[] split = command.split("\n");
            if (split.length >= 3) {
                String[] maxCoordinate = split[0].split(" ");
                if (maxCoordinate.length > 2) {
                    throw new IllegalCharacterException("非法字符输入");
                }
                ProberBO maxProberBO = new ProberBO();
                maxProberBO.setXCoordinate(Integer.valueOf(maxCoordinate[0]));
                maxProberBO.setYCoordinate(Integer.valueOf(maxCoordinate[1]));

                for (int i = 1; i < split.length; i = i + 2) {
                    String[] coordinate = split[i].split(" ");
                    if (coordinate.length > 3) {
                        throw new IllegalCharacterException("非法字符输入");
                    }
                    String moveCommand = split[i + 1];
                    ProberBO proberBO = new ProberBO();
                    proberBO.setXCoordinate(Integer.valueOf(coordinate[0]));
                    proberBO.setYCoordinate(Integer.valueOf(coordinate[1]));
                    proberBO.setDirection(coordinate[2]);
                    for (int j = 0; j < moveCommand.length(); j++) {
                        String currentCommand = String.valueOf(moveCommand.charAt(j));
                        if (DirectionRuleUtil.MOVE_DIRECTION_LIST.contains(currentCommand)) {
                            proberBO.setDirection(DirectionRuleUtil.nextDirection(proberBO.getDirection(), currentCommand));
                        } else {
                            proberBO = DirectionRuleUtil.nextCoordinate(proberBO, currentCommand);
                            boolean checkResult = DirectionRuleUtil.checkCoordinate(proberBO, maxProberBO.getXCoordinate(), maxProberBO.getYCoordinate());
                            if (!checkResult) {
                                //throw new OutOfCoordinateException("探测器越界");
                                resultMap.setMsg("探测器越界");
                                return resultMap;
                            }
                        }
                    }
                    resultT = resultT + proberBO.toString();
                }
                resultMap.setT(resultT.substring(1));
                resultMap.setResult(Boolean.TRUE);
                return resultMap;
            }
        } catch (Exception e) {
            log.error("execute {} ,error.", command, e.getMessage());
        }
        resultMap.setMsg("可能有非法字符或错误的命令");
        return resultMap;
    }
}
