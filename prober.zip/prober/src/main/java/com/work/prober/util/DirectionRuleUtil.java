package com.work.prober.util;

import com.work.prober.bean.ProberBO;
import com.work.prober.exception.IllegalCharacterException;

import java.util.Arrays;
import java.util.List;

/**
 * @author zhuzhe
 * @date 2018/8/3 15:11
 * @email zhe.zhu1@outlook.com
 */
public class DirectionRuleUtil {

    public static final String DIRECTION_LEFT = "L";
    public static final String DIRECTION_RIGHT = "R";

    public static final String DIRECTION_NORTH = "N";
    public static final String DIRECTION_SOUTH = "S";
    public static final String DIRECTION_WEST = "W";
    public static final String DIRECTION_EAST = "E";

    /*  M表示向前开进一个网格的距离，保持方向不变 */
    public static final String MOVE_M = "M";

    public static final List<String> MOVE_DIRECTION_LIST = Arrays.asList(DIRECTION_LEFT, DIRECTION_RIGHT);
    public static final List<String> MOVE_ACTION_LIST = Arrays.asList(MOVE_M);

    /**
     * 计算下一个方向
     *
     * @param currentDirection 当前方向
     * @param direction        转向   【 L - 左转 ； R - 右转 】
     * @return
     */
    public static String nextDirection(String currentDirection, String direction) {

        if (DIRECTION_LEFT.equals(direction)) {
            switch (currentDirection) {
                case DIRECTION_NORTH:
                    return DIRECTION_WEST;
                case DIRECTION_SOUTH:
                    return DIRECTION_EAST;
                case DIRECTION_WEST:
                    return DIRECTION_SOUTH;
                case DIRECTION_EAST:
                    return DIRECTION_NORTH;
            }
        } else if (DIRECTION_RIGHT.equals(direction)) {
            switch (currentDirection) {
                case DIRECTION_NORTH:
                    return DIRECTION_EAST;
                case DIRECTION_SOUTH:
                    return DIRECTION_WEST;
                case DIRECTION_WEST:
                    return DIRECTION_NORTH;
                case DIRECTION_EAST:
                    return DIRECTION_SOUTH;
            }
        }
        throw new IllegalCharacterException("非法的字符");
    }

    /**
     * 计算下一个坐标
     *
     * @param proberBO 当前探测器
     * @param move     动作
     * @return 返回探测器移动后新的位置
     */
    public static ProberBO nextCoordinate(ProberBO proberBO, String move) {
        if (MOVE_M.equals(move)) {
            switch (proberBO.getDirection()) {
                case DIRECTION_NORTH:
                    proberBO.setYCoordinate(proberBO.getYCoordinate() + 1);
                    return proberBO;
                case DIRECTION_SOUTH:
                    proberBO.setYCoordinate(proberBO.getYCoordinate() - 1);
                    return proberBO;
                case DIRECTION_WEST:
                    proberBO.setXCoordinate(proberBO.getXCoordinate() - 1);
                    return proberBO;
                case DIRECTION_EAST:
                    proberBO.setXCoordinate(proberBO.getXCoordinate() + 1);
                    return proberBO;
            }
        }
        throw new IllegalCharacterException("非法的字符");
    }

    /**
     * 注：默认X Y轴最小坐标为 0
     *
     * @param proberBO
     * @param maxXCoordinate X轴最大坐标
     * @param maxYCoordinate Y轴最大坐标
     * @return
     */
    public static boolean checkCoordinate(ProberBO proberBO, Integer maxXCoordinate, Integer maxYCoordinate) {
        if (proberBO.getXCoordinate() > maxXCoordinate || proberBO.getXCoordinate() < 0
                || proberBO.getYCoordinate() > maxYCoordinate || proberBO.getYCoordinate() < 0) {
            return false;
        }
        return true;
    }
}
