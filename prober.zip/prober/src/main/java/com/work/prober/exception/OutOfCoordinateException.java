package com.work.prober.exception;

/**
 * @author zhuzhe
 * @date 2018/8/3 17:24
 * @email zhe.zhu1@outlook.com
 */
public class OutOfCoordinateException extends RuntimeException {

    public OutOfCoordinateException() {
        super();
    }

    public OutOfCoordinateException(String message) {
        super(message);
    }
}
