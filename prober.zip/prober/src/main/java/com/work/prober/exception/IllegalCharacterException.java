package com.work.prober.exception;

/**
 * @author zhuzhe
 * @date 2018/8/3 15:20
 * @email zhe.zhu1@outlook.com
 */
public class IllegalCharacterException extends RuntimeException {

    public IllegalCharacterException() {
        super();
    }

    public IllegalCharacterException(String message) {
        super(message);
    }
}
