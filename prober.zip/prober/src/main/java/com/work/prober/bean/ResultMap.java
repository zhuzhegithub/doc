package com.work.prober.bean;

import lombok.Data;

import java.util.List;

/**
 * @author zhuzhe
 * @date 2018/8/3 16:41
 * @email zhe.zhu1@outlook.com
 */
@Data
public class ResultMap<T> {

    private Boolean result = false;

    private T t;

    /* result == false 时有msg */
    private String msg;
}
