package com.work.prober.bean;

import lombok.Data;

/**
 * @author zhuzhe
 * @date 2018/8/3 14:48
 * @email zhe.zhu1@outlook.com
 */
@Data
public class ProberBO {

    /* x坐标 */
    private Integer xCoordinate;

    /* y坐标 */
    private Integer yCoordinate;

    /* 方向 */
    private String direction;

    /* 其他成员变量... */

    public String toString() {
        return "\n" + xCoordinate + " " + yCoordinate + " " + direction;
    }
}
